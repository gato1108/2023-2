A = rand(2,3);
B = rand(3,3);
C = rand(3,2);
D = rand(3,3);
%(a)
2*A+C.'

%(C)
3*B-2*D

%(D)
A*D

%(E)
C*A

%(F)
A*C

%(G)
B*D

%(I)
C.'*B

%(K)
det(D)

%(L)
A*A.'

%(M)
A.'*A

%(N)
det(A*A.')

%(O)
det(A.'*A)